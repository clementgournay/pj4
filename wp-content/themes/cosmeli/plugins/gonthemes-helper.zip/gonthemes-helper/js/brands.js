(function($) {
	"use strict";
	
	jQuery(document).ready(function(){
		$('.brands-carousel').owlCarousel({
			nav: false,
			dots: false,
			loop: true,
			responsive: {
				0: {
					items: 1,
				},
				480: {
					items: 2,
				},
				768: {
					items: 4,
				},
				1024: {
					items: 6,
				},
			}
		});
	});
})(jQuery);