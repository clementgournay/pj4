<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mapping shortcodes
 */
function gon_map_sc_google_map() {
	// Mapping shortcode Google Map
	vc_map(
		array(
			'name'                    => esc_html__( 'Google Map', 'gonthemes-helper' ),
			'base'                    => 'gon-google-map',
			'category'                => esc_html__( 'GonThemes Helper', 'gonthemes-helper' ),
			'description'             => esc_html__( 'Display Google map.', 'gonthemes-helper' ),
			'controls'                => 'full',
			'show_settings_on_create' => true,
			'params'                  => array(
				// Map center
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Map center', 'gonthemes-helper' ),
					'param_name'  => 'map_center',
					'admin_label' => true,
					'value'       => '',
					'description' => esc_html__( 'The name of a place, town, city, or even a country. Can be an exact address too.', 'gonthemes-helper' ),

				),
				// Map height
				array(
					'type'        => 'number',
					'admin_label' => true,
					'heading'     => esc_html__( 'Height', 'gonthemes-helper' ),
					'param_name'  => 'height',
					'min'         => 0,
					'value'       => 480,
					'suffix'      => 'px',
					'description' => esc_html__( 'Height of the map.', 'gonthemes-helper' ),
				),
				// Zoom options
				array(
					'type'        => 'number',
					'admin_label' => true,
					'heading'     => esc_html__( 'Zoom level', 'gonthemes-helper' ),
					'param_name'  => 'zoom',
					'min'         => 0,
					'max'         => 21,
					'value'       => 12,
					'description' => esc_html__( 'A value from 0 (the world) to 21 (street level).', 'gonthemes-helper' ),
				),
				// Show marker
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'Marker', 'gonthemes-helper' ),
					'param_name'  => 'marker_at_center',
					'value'       => array( esc_html__( '', 'gonthemes-helper' ) => 'true' ),
					'description' => esc_html__( 'Show marker at map center.', 'gonthemes-helper' ),
				),
				// Get marker
				array(
					'type'        => 'attach_image',
					'heading'     => esc_html__( 'Choose marker icon', 'gonthemes-helper' ),
					'param_name'  => 'marker_icon',
					'admin_label' => true,
					'value'       => '',
					'description' => esc_html__( 'Replaces the default map marker with your own image.', 'gonthemes-helper' ),
					'dependency'  => array( 'element' => 'marker_at_center', 'value' => array( 'true' ) )
				),
				// Other options
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'Scroll to zoom', 'gonthemes-helper' ),
					'param_name'  => 'scroll_zoom',
					'value'       => array( esc_html__( '', 'gonthemes-helper' ) => 'true' ),
					'description' => esc_html__( 'Allow scrolling over the map to zoom in or out.', 'gonthemes-helper' ),
				),
				// Other options
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'Draggable', 'gonthemes-helper' ),
					'param_name'  => 'draggable',
					'value'       => array( esc_html__( '', 'gonthemes-helper' ) => 'true' ),
					'description' => esc_html__( 'Allow dragging the map to move it around.', 'gonthemes-helper' ),
				),
				// Google API
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Google map API', 'gonthemes-helper' ),
					'param_name'  => 'map_api',
					'admin_label' => true,
					'value'       => 'AIzaSyBEswjEJ9Ivw2YWIx_ztXyKi3ZiO1p6mws',
					'description' => esc_html__( 'Enter API google map of you or create new API: https://developers.google.com/maps/documentation/javascript/get-api-key', 'gonthemes-helper' ),

				),
				// Animation
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Animation', 'gonthemes-helper' ),
					'param_name'  => 'animation',
					'value'       => array(
						__( 'No', 'gonthemes-helper' )                 => '',
						__( 'Top to bottom', 'gonthemes-helper' )      => 'top-to-bottom',
						__( 'Bottom to top', 'gonthemes-helper' )      => 'bottom-to-top',
						__( 'Left to right', 'gonthemes-helper' )      => 'left-to-right',
						__( 'Right to left', 'gonthemes-helper' )      => 'right-to-left',
						__( 'Appear from center', 'gonthemes-helper' ) => 'appear'
					),
					'description' => esc_html__( 'Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'gonthemes-helper' )
				),
				// Extra class
				array(
					'type'        => 'textfield',
					'admin_label' => true,
					'heading'     => esc_html__( 'Extra class', 'gonthemes-helper' ),
					'param_name'  => 'el_class',
					'value'       => '',
					'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'gonthemes-helper' ),
				),

			)
		)
	);
}
add_action( 'vc_before_init', 'gon_map_sc_google_map' );

/**
 * Shortcode Google Map
 *
 * @param $atts
 *
 * @return string
 */
function gon_shortcode_google_map( $atts ) {

	wp_enqueue_script( 'gon-google-map', GON_URL . 'js/google-map.js', array( 'jquery' ), '', true );

	$google_map = shortcode_atts(
		array(
			'title'            => esc_html__( 'Our Address', 'themes-helper' ),
			'map_center'       => '',
			'height'           => '',
			'zoom'             => '',
			'scroll_zoom'      => '',
			'draggable'        => '',
			'marker_at_center' => '',
			'marker_icon'      => '',
			'map_api'		   => 'AIzaSyBEswjEJ9Ivw2YWIx_ztXyKi3ZiO1p6mws',
			'animation'        => '',
			'el_class'         => '',
		), $atts
	);

	$animation = gon_getCSSAnimation( $google_map['animation'] );

	// Get settings
	$id     = 'map-canvas-' . md5( $google_map['map_center'] ) . '';
	$height = $google_map['height'] . 'px';
	$data   = 'data-address="' . $google_map['map_center'] . '" ';
	$data .= 'data-zoom="' . $google_map['zoom'] . '" ';
	$data .= 'data-scroll-zoom="' . $google_map['scroll_zoom'] . '" ';
	$data .= 'data-draggable="' . $google_map['draggable'] . '" ';
	$data .= 'data-marker-at-center="' . $google_map['marker_at_center'] . '" ';
	$data .= 'data-google-map-api="' . $google_map['map_api'] . '" ';

	$icon_src = wp_get_attachment_image_src( $google_map['marker_icon'] );
	$icon     = isset( $icon_src[0] ) ? $icon_src[0] : '';
	$data .= 'data-marker-icon="' . $icon . '" ';

	$class = 'google-map-canvas';

	$html = '<div class="' . $class . ' ' . $animation . ' ' . esc_attr( $google_map['el_class'] ) . '" id="' . $id . '" style="height: ' . $height . ';" ' . $data . ' ></div>';

	return $html;
}

add_shortcode( 'gon-google-map', 'gon_shortcode_google_map' );