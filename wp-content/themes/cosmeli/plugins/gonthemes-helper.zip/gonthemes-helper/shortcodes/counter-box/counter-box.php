<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mapping shortcodes
 */
function gon_map_sc_counter_box() {
	// Mapping shortcode Counter Box
	vc_map( array(
		'name'        => esc_html__( 'Counter Box', 'gonthemes-helper' ),
		'base'        => 'gon-counter-box',
		'class'       => '',
		'category'    => esc_html__( 'GonThemes Helper', 'gonthemes-helper' ),
		'description' => esc_html__( 'Display counter box.', 'gonthemes-helper' ),
		'params'      => array(

			//Circle box color
			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Circle color', 'gonthemes-helper' ),
				'param_name'  => 'b_color',
				'value'       => esc_html__( '', 'gonthemes-helper' ),
				'description' => esc_html__( 'Select the circle box background color', 'gonthemes-helper' )
			),
			// Count to number
			array(
				'type'        => 'number',
				'admin_label' => true,
				'value'       => 10,
				'min'         => 0,
				'heading'     => esc_html__( 'Number', 'gonthemes-helper' ),
				'param_name'  => 'number',
				'description' => esc_html__( 'Enter number in box to count.', 'gonthemes-helper' ),
			),
			//Number color
			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Number color', 'gonthemes-helper' ),
				'param_name'  => 'number_color',
				'value'       => esc_html__( '', 'gonthemes-helper' ),
				'description' => esc_html__( 'Select the number color', 'gonthemes-helper' )
			),
			// Text
			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Text', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'text',
				'value'       => '',
				'description' => esc_html__( 'Short text in counter box.', 'gonthemes-helper' ),
			),
			//Text color
			array(
				'type'        => 'colorpicker',
				'heading'     => esc_html__( 'Text color', 'gonthemes-helper' ),
				'param_name'  => 'text_color',
				'value'       => esc_html__( '', 'gonthemes-helper' ),
				'description' => esc_html__( 'Select the text color', 'gonthemes-helper' )
			),
			// Extra class
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				'heading'     => esc_html__( 'Extra class', 'gonthemes-helper' ),
				'param_name'  => 'el_class',
				'value'       => '',
				'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'gonthemes-helper' ),
			),
		)
	) );
}
add_action( 'vc_before_init', 'gon_map_sc_counter_box' );

/**
 * Shortcode Counter Box
 *
 * @param $atts
 *
 * @return string
 */
function gon_shortcode_counter_box( $atts ) {

	wp_enqueue_script( 'gon-counter-box', GON_URL . 'js/counter-box.js', array( 'jquery' ), '', true );

	$counter_box = shortcode_atts( array(
		'number'       => '',
		'number_color' => '',
		'text'         => '',
		'text_color'   => '',
		'b_color'      => '',
		'el_class'     => '',
	), $atts );
	$html        = '';

	$circle_color = '';
	if ( $counter_box['b_color'] ) {
		$circle_color = 'style = background-color:' . $counter_box['b_color'] . '; ';
	}


	$number_color = '';
	if ( $counter_box['number_color'] ) {
		$number_color = 'style = color:' . $counter_box['number_color'] . '; ';
	}

	$text_color = '';
	if ( $counter_box['text_color'] ) {
		$text_color = 'style = color:' . $counter_box['text_color'] . '; ';
	}

	$html .=
		'<div class="result-box ' . esc_attr( $counter_box['el_class'] ) . '" ' . $circle_color . '>
			<div class="statistic">
				<div class="number" ' . $number_color . '>
					<span class="timer" data-from="0" data-to="' . $counter_box['number'] . '">"'.$counter_box['number'] .'"</span>
					<span class="counter-text" ' . $text_color . '>' . esc_attr( $counter_box['text'] ) . '</span>
				</div>
				
			</div>
		</div>';

	return $html;
}

add_shortcode( 'gon-counter-box', 'gon_shortcode_counter_box' );
