<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mapping shortcodes
 */
function gon_map_sc_testimonials() {
	// Mapping shortcode Counter Box
	vc_map( array(
		'name'        => esc_html__( 'Testimonials', 'gonthemes-helper' ),
		'base'        => 'gon-testimonials',
		'class'       => '',
		'category'    => esc_html__( 'GonThemes Helper', 'gonthemes-helper' ),
		'description' => esc_html__( 'Display testimonials.', 'gonthemes-helper' ),
		'params'      => array(
			array(
				'type'       => 'param_group',
				'heading'    => esc_html__( 'Items', 'creative-mag' ),
				'param_name' => 'items',
				'value'      => '',
				'params'     => array(
					// Name
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Name', 'gonthemes-helper' ),
						'admin_label' => true,
						'param_name'  => 'name',
						'value'       => esc_html__( 'Jane Doe', 'gonthemes-helper' ),
					),
					// Jobs
					array(
						'type'        => 'textfield',
						'heading'     => esc_html__( 'Jobs', 'gonthemes-helper' ),
						'admin_label' => true,
						'param_name'  => 'jobs',
						'value'       => esc_html__( 'Web Developer', 'gonthemes-helper' ),
					),
					// Description
					array(
						'type'        => 'textarea',
						'heading'     => esc_html__( 'Description', 'gonthemes-helper' ),
						'admin_label' => true,
						'param_name'  => 'description',
						'value'       => esc_html__( 'Habitasse lobortis cum malesuada nullam cras odio venenatis nisl at turpis sem in porta consequat massa a mus massa nascetur elit vestibulum.', 'gonthemes-helper' ),
					),
					array(
						"type"        => "attach_image",
						"heading"     => esc_attr__( "Choose an avatar", 'gonthemes-helper' ),
						"param_name"  => "avatar",
						"admin_label" => true,
						"description" => esc_attr__( "Select an image to upload", 'gonthemes-helper' )
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Brand Link', 'creative-mag' ),
						'param_name' => 'link',
						'value'       => '#',
					),
				)
			),
			
			// Extra class
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				'heading'     => esc_html__( 'Extra class', 'gonthemes-helper' ),
				'param_name'  => 'el_class',
				'value'       => '',
				'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'gonthemes-helper' ),
			),
		)
	) );
}
add_action( 'vc_before_init', 'gon_map_sc_testimonials' );

/**
 * Shortcode Testimonials
 *
 * @param $atts
 *
 * @return string
 */
function gon_shortcode_testimonials( $atts ) {

	wp_enqueue_script( 'gon-testimonials', GON_URL . 'js/testimonials.js', array( 'jquery' ), '', true );

	$testimonials = shortcode_atts( array(
		'items'      	=> '',
		'el_class'     => '',
	), $atts );
	$testimonials['items'] = vc_param_group_parse_atts( $testimonials['items'] );
	$html = '';

	$html .= '<div class="testimonials ' . esc_attr( $testimonials['el_class'] ) . '">';
	$html .= '<div class="testimonial-carousel owl-carousel owl-theme">';
	if ( $testimonials['items'] ) {
		foreach ( $testimonials['items'] as $key => $item ) {
			$item_img = wp_get_attachment_image_src( $item['avatar'], 'full' );
			$img_crop = aq_resize($item_img[0], 100, 100, true);
			if($img_crop) {
				$img = '<img src="'.$img_crop.'" alt="'.$item['name'].'">';
			} else {
				$img = '<img src="'.$item_img[0].'" alt="'.$item['name'].'">';
			}
			$html .= '<div class="single-testimonial">';
				$html .= '<div class="testimonials-wrapper">';
					$html .= '<h4>' . $item['description'] . '</h4>';
					$html .= '<span class="testimonials-blob"></span>';
					$html .= '<div class="testimonials-img"><a href="'.$item['link'].'">'.$img.'</a></div>';
					$html .= '<div class="testimonials-person-info">';
						$html .= '<p><b>'.$item['name'].'</b><br />'.$item['jobs'].'</p>';
					$html .= '</div>';
				$html .= '</div>';
			$html .= '</div>';
		}
	}
	$html .= '</div>';
	$html .= '</div>';

	return $html;
}

add_shortcode( 'gon-testimonials', 'gon_shortcode_testimonials' );
