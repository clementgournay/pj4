<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mapping shortcodes
 */
function gon_map_sc_icon_box() {
	// Mapping shortcode Icon Box
	vc_map(
		array(
			'name'                    => esc_html__( 'Icon Box', 'gonthemes-helper' ),
			'base'                    => 'gon-icon-box',
			'category'                => esc_html__( 'GonThemes Helper', 'gonthemes-helper' ),
			'description'             => esc_html__( 'Display icon box with image or icon.', 'gonthemes-helper' ),
			'controls'                => 'full',
			'show_settings_on_create' => true,
			'params'                  => array(

				array(
					'type'        => 'radioimage',
					'heading'     => esc_html__( 'Layout', 'gonthemes-helper' ),
					'class'       => 'icon-box-layout',
					'param_name'  => 'layout',
					'admin_label' => true,
					'options'     => array(
						'top'  => GON_URL . 'images/image-top.jpg',
						'top2' => GON_URL . 'images/icon-top.jpg',
						'left' => GON_URL . 'images/icon-left.jpg'
					),
					'description' => esc_html__( 'Choose the layout you want to display.', 'gonthemes-helper' ),
				),
				// Title
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Title', 'gonthemes-helper' ),
					'param_name'  => 'title',
					'admin_label' => true,
					'value'       => esc_html__( 'This is an icon box.', 'gonthemes-helper' ),
					'description' => esc_html__( 'Provide the title for this icon box.', 'gonthemes-helper' ),
				),
				//Use custom or default title?
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Use custom or default title?', 'gonthemes-helper' ),
					'param_name'  => 'title_custom',
					'value'       => array(
						__( 'Default', 'gonthemes-helper' ) => '',
						__( 'Custom', 'gonthemes-helper' )  => 'custom',
					),
					'description' => esc_html__( 'If you select default you will use default title which customized in typography.', 'gonthemes-helper' )
				),
				//Heading
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Heading element', 'gonthemes-helper' ),
					'param_name'  => 'heading_tag',
					'value'       => array(
						'h3' => 'h3',
						'h2' => 'h2',
						'h4' => 'h4',
						'h5' => 'h5',
						'h6' => 'h6',
					),
					'description' => esc_html__( 'Choose heading type of the title.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'title_custom',
						'value'   => 'custom',
					),
				),
				//Title color
				array(
					'type'        => 'colorpicker',
					'admin_label' => true,
					'heading'     => esc_html__( 'Title color ', 'gonthemes-helper' ),
					'param_name'  => 'title_color',
					'value'       => esc_html__( '', 'gonthemes-helper' ),
					'description' => esc_html__( 'Select the title color.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'title_custom',
						'value'   => 'custom',
					),
				),
				//Title size
				array(
					'type'        => 'number',
					'admin_label' => true,
					'heading'     => esc_html__( 'Title size ', 'gonthemes-helper' ),
					'param_name'  => 'title_size',
					'min'         => 0,
					'value'       => '',
					'suffix'      => 'px',
					'description' => esc_html__( 'Select the title size.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'title_custom',
						'value'   => 'custom',
					),
				),

				//Title weight
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Title weight ', 'gonthemes-helper' ),
					'param_name'  => 'title_weight',
					'value'       => array(
						__( 'Choose the title font weight', 'gonthemes-helper' ) => '',
						__( 'Lighter', 'gonthemes-helper' )                      => '300',
						__( 'Normal', 'gonthemes-helper' )                       => '400',
						__( 'Medium', 'gonthemes-helper' )                      => '500',
						__( 'SemiBold', 'gonthemes-helper' )                       => '600',
						__( 'Bold', 'gonthemes-helper' )                         => '700',
					),
					'description' => esc_html__( 'Select the title weight.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'title_custom',
						'value'   => 'custom',
					),
				),
				//Title style
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Title style ', 'gonthemes-helper' ),
					'param_name'  => 'title_style',
					'value'       => array(
						__( 'Choose the title font style', 'gonthemes-helper' ) => '',
						__( 'Italic', 'gonthemes-helper' )                      => 'italic',
						__( 'Oblique', 'gonthemes-helper' )                     => 'oblique',
						__( 'Initial', 'gonthemes-helper' )                     => 'initial',
						__( 'Inherit', 'gonthemes-helper' )                     => 'inherit',
					),
					'description' => esc_html__( 'Select the title style.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'title_custom',
						'value'   => 'custom',
					),
				),
				// Description
				array(
					'type'        => 'textarea',
					'admin_label' => true,
					'heading'     => esc_html__( 'Description', 'gonthemes-helper' ),
					'param_name'  => 'description',
					'value'       => esc_html__( '', 'gonthemes-helper' ),
					'description' => esc_html__( 'Provide the description for this icon box.', 'gonthemes-helper' )
				),
				//Use custom or default description ?
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Use custom or default description?', 'gonthemes-helper' ),
					'param_name'  => 'description_custom',
					'value'       => array(
						__( 'Default', 'gonthemes-helper' ) => '',
						__( 'Custom', 'gonthemes-helper' )  => 'custom',
					),
					'description' => esc_html__( 'If you select default you will use default description which customized in typography.', 'gonthemes-helper' )
				),
				//Description color
				array(
					'type'        => 'colorpicker',
					'admin_label' => true,
					'heading'     => esc_html__( 'Description color ', 'gonthemes-helper' ),
					'param_name'  => 'description_color',
					'value'       => esc_html__( '', 'gonthemes-helper' ),
					'description' => esc_html__( 'Select the description color.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'description_custom',
						'value'   => 'custom',
					),
				),
				//Description size
				array(
					'type'        => 'number',
					'admin_label' => true,
					'heading'     => esc_html__( 'Description size ', 'gonthemes-helper' ),
					'param_name'  => 'description_size',
					'min'         => 0,
					'value'       => '',
					'suffix'      => 'px',
					'description' => esc_html__( 'Select the description size.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'description_custom',
						'value'   => 'custom',
					),
				),
				//Description weight
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Description weight ', 'gonthemes-helper' ),
					'param_name'  => 'description_weight',
					'value'       => array(
						__( 'Choose the description font weight', 'gonthemes-helper' ) => '',
						__( 'Lighter', 'gonthemes-helper' )                      => '300',
						__( 'Normal', 'gonthemes-helper' )                       => '400',
						__( 'Medium', 'gonthemes-helper' )                      => '500',
						__( 'SemiBold', 'gonthemes-helper' )                       => '600',
						__( 'Bold', 'gonthemes-helper' )                         => '700',
					),
					'description' => esc_html__( 'Select the description weight.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'description_custom',
						'value'   => 'custom',
					),
				),
				//Description style
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Description style ', 'gonthemes-helper' ),
					'param_name'  => 'description_style',
					'value'       => array(
						__( 'Choose the description font style', 'gonthemes-helper' ) => '',
						__( 'Italic', 'gonthemes-helper' )                            => 'italic',
						__( 'Oblique', 'gonthemes-helper' )                           => 'oblique',
						__( 'Initial', 'gonthemes-helper' )                           => 'initial',
						__( 'Inherit', 'gonthemes-helper' )                           => 'inherit',
					),
					'description' => esc_html__( 'Select the description style.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'description_custom',
						'value'   => 'custom',
					),
				),
				// Icon type
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Icon type', 'gonthemes-helper' ),
					'value'       => array(
						__( 'Choose icon type', 'gonthemes-helper' ) => '',
						__( 'Single Image', 'gonthemes-helper' )     => 'image',
						__( 'Font Awesome', 'gonthemes-helper' )     => 'fontawesome',
						__( 'Openiconic', 'gonthemes-helper' )       => 'openiconic',
						__( 'Typicons', 'gonthemes-helper' )         => 'typicons',
						__( 'Entypo', 'gonthemes-helper' )           => 'entypo',
						__( 'Linecons', 'gonthemes-helper' )         => 'linecons',
						__( 'Simple Line Icons', 'gonthemes-helper' ) => 'simplelineicons',
					),
					'admin_label' => true,
					'param_name'  => 'icon_type',
					'description' => esc_html__( 'Select icon type.', 'gonthemes-helper' ),
				),
				// Icon type: Image - Image picker
				array(
					'type'        => 'attach_image',
					'heading'     => esc_html__( 'Choose image', 'gonthemes-helper' ),
					'param_name'  => 'icon_image',
					'admin_label' => true,
					'value'       => '',
					'description' => esc_html__( 'Upload the custom image icon.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'image',
					),
				),
				//Image size
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Image size', 'gonthemes-helper' ),
					'param_name'  => 'image_size',
					'admin_label' => true,
					'description' => esc_html__( 'Enter image size. Example: "thumbnail", "medium", "large", "full" or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'image',
					),
				),
				// Icon type: Fontawesome - Icon picker
				array(
					'type'        => 'iconpicker',
					'admin_label' => true,
					'heading'     => esc_html__( 'Icon', 'gonthemes-helper' ),
					'param_name'  => 'icon_fontawesome',
					'value'       => 'fa fa-heart',
					'settings'    => array(
						'emptyIcon'    => false,
						'iconsPerPage' => 50,
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'fontawesome',
					),
					'description' => esc_html__( 'FontAwesome library.', 'gonthemes-helper' ),
				),
				// Icon type: Openiconic - Icon picker
				array(
					'type'        => 'iconpicker',
					'admin_label' => true,
					'heading'     => esc_html__( 'Icon', 'gonthemes-helper' ),
					'param_name'  => 'icon_openiconic',
					'value'       => '',
					'settings'    => array(
						'emptyIcon'    => false,
						'iconsPerPage' => 50,
						'type'         => 'openiconic',
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'openiconic',
					),
					'description' => esc_html__( 'Openiconic library.', 'gonthemes-helper' ),
				),
				// Icon type: Typicons - Icon picker
				array(
					'type'        => 'iconpicker',
					'admin_label' => true,
					'heading'     => esc_html__( 'Icon', 'gonthemes-helper' ),
					'param_name'  => 'icon_typicons',
					'value'       => '',
					'settings'    => array(
						'emptyIcon'    => false,
						'iconsPerPage' => 50,
						'type'         => 'typicons',
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'typicons',
					),
					'description' => esc_html__( 'Typicons library.', 'gonthemes-helper' ),
				),
				// Icon type: Entypo - Icon picker
				array(
					'type'        => 'iconpicker',
					'admin_label' => true,
					'heading'     => esc_html__( 'Icon', 'gonthemes-helper' ),
					'param_name'  => 'icon_entypo',
					'value'       => '',
					'settings'    => array(
						'emptyIcon'    => false,
						'iconsPerPage' => 50,
						'type'         => 'entypo',
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'entypo',
					),
					'description' => esc_html__( 'Entypo library.', 'gonthemes-helper' ),
				),
				// Icon type: Lincons - Icon picker
				array(
					'type'        => 'iconpicker',
					'admin_label' => true,
					'heading'     => esc_html__( 'Icon', 'gonthemes-helper' ),
					'param_name'  => 'icon_linecons',
					'value'       => '',
					'settings'    => array(
						'emptyIcon'    => false,
						'iconsPerPage' => 50,
						'type'         => 'linecons',
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'linecons',
					),
					'description' => esc_html__( 'Linecons library.', 'gonthemes-helper' ),
				),
				// Icon type: Simple Line Icons - Icon picker
				array(
					'type'        => 'iconpicker',
					'admin_label' => true,
					'heading'     => esc_html__( 'Icon', 'gonthemes-helper' ),
					'param_name'  => 'icon_simplelineicons',
					'value'       => '',
					'settings'    => array(
						'emptyIcon'    => false,
						'iconsPerPage' => 50,
						'type'         => 'simplelineicons',
					),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => 'simplelineicons',
					),
					'description' => esc_html__( 'Simple Line Icons library.', 'gonthemes-helper' ),
				),

				//Icon link
				array(
					'type'        => 'vc_link',
					'heading'     => __( 'Icon link', 'gonthemes-helper' ),
					'param_name'  => 'icon_link',
					'admin_label' => true,
					'description' => __( 'Enter the link for icon.', 'gonthemes-helper' ),
				),

				//Icon size
				array(
					'type'        => 'number',
					'admin_label' => true,
					'heading'     => esc_html__( 'Icon size', 'gonthemes-helper' ),
					'param_name'  => 'icon_size',
					'value'       => 26,
					'min'         => 16,
					'max'         => 100,
					'suffix'      => 'px',
					'description' => esc_html__( 'Select the icon size.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => array( 'fontawesome', 'openiconic', 'typicons', 'entypo', 'linecons', 'simplelineicons' ),
					),
				),
				//Icon color
				array(
					'type'        => 'colorpicker',
					'heading'     => esc_html__( 'Icon color', 'gonthemes-helper' ),
					'param_name'  => 'icon_color',
					'value'       => '#fff',
					'description' => esc_html__( 'Select the icon color.', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'icon_type',
						'value'   => array( 'fontawesome', 'openiconic', 'typicons', 'entypo', 'linecons', 'simplelineicons' ),
					),
				),
				//Display the button?
				array(
					'type'        => 'checkbox',
					'heading'     => esc_html__( 'Display the button?', 'gonthemes-helper' ),
					'param_name'  => 'button_display',
					'value'       => array( esc_html__( '', 'gonthemes-helper' ) => 'yes' ),
					'description' => esc_html__( 'Tick it to display the button.', 'gonthemes-helper' ),
				),
				//Button link
				array(
					'type'        => 'vc_link',
					'heading'     => esc_html__( 'Button link', 'gonthemes-helper' ),
					'param_name'  => 'button_link',
					'value'       => esc_html__( '', 'gonthemes-helper' ),
					'description' => esc_html__( 'Write the button link', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'button_display',
						'value'   => 'yes',
					),
				),
				//Button value
				array(
					'type'        => 'textfield',
					'admin_label' => true,
					'heading'     => esc_html__( 'Button value', 'gonthemes-helper' ),
					'param_name'  => 'button_value',
					'value'       => esc_html__( '', 'gonthemes-helper' ),
					'description' => esc_html__( 'Write the button value', 'gonthemes-helper' ),
					'dependency'  => array(
						'element' => 'button_display',
						'value'   => 'yes',
					),
				),
				//Background color
				array(
					'type'        => 'colorpicker',
					'heading'     => esc_html__( 'Background color', 'gonthemes-helper' ),
					'param_name'  => 'background_color',
					'value'       => '',
					'description' => esc_html__( 'Select the background color.', 'gonthemes-helper' ),
				),
				//Text Alignment
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Text alignment', 'gonthemes-helper' ),
					'param_name'  => 'alignment',
					'value'       => array(
						__( 'Choose the text alignment', 'gonthemes-helper' ) => '',
						__( 'Text at left', 'gonthemes-helper' )              => 'left',
						__( 'Text at center', 'gonthemes-helper' )            => 'center',
						__( 'Text at right', 'gonthemes-helper' )             => 'right',
					),
				),
				// Animation
				array(
					'type'        => 'dropdown',
					'admin_label' => true,
					'heading'     => esc_html__( 'Animation', 'gonthemes-helper' ),
					'param_name'  => 'css_animation',
					'value'       => array(
						__( 'No', 'gonthemes-helper' )                 => '',
						__( 'Top to bottom', 'gonthemes-helper' )      => 'top-to-bottom',
						__( 'Bottom to top', 'gonthemes-helper' )      => 'bottom-to-top',
						__( 'Left to right', 'gonthemes-helper' )      => 'left-to-right',
						__( 'Right to left', 'gonthemes-helper' )      => 'right-to-left',
						__( 'Appear from center', 'gonthemes-helper' ) => 'appear'
					),
					'description' => esc_html__( 'Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'gonthemes-helper' )
				),
				// Extra class
				array(
					'type'        => 'textfield',
					'admin_label' => true,
					'heading'     => esc_html__( 'Extra class', 'gonthemes-helper' ),
					'param_name'  => 'el_class',
					'value'       => '',
					'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'gonthemes-helper' ),
				),
			)
		)
	);
}
add_action( 'vc_before_init', 'gon_map_sc_icon_box' );

/**
 * Shortcode Icon Box
 *
 * @param $atts
 *
 * @return string
 */

function gon_shortcode_icon_box( $atts ) {

	$icon_box = shortcode_atts( array(
		'layout'             => '',
		'title'              => '',
		'heading_tag'        => 'h3',
		'title_color'        => '',
		'title_size'         => '',
		'title_weight'       => '',
		'title_style'        => '',
		'title_custom'       => '',
		'description'        => '',
		'description_color'  => '',
		'description_size'   => '',
		'description_weight' => '',
		'description_style'  => '',
		'description_custom' => '',
		'background_color'   => '',
		'icon_type'          => '',
		'icon_fontawesome'   => '',
		'icon_openiconic'    => '',
		'icon_typicons'      => '',
		'icon_entypo'        => '',
		'icon_linecons'      => '',
		'icon_simplelineicons'  => '',
		'icon_link'          => '',
		'icon_size'          => '40',
		'icon_color'         => '',
		'icon_image'         => '',
		'image_size'         => '',
		'button_display'     => '',
		'button_value'       => 'LEARN MORE',
		'button_link'        => '',
		'alignment'          => '',
		'el_class'           => '',
		'css_animation'      => '',

	), $atts );

	$css_animation = gon_getCSSAnimation( $icon_box['css_animation'] );

	$column_class = '';
	if ( $icon_box['layout'] == 'left' ) {
		$column_class = 'pull-left';
	}

	// Icon link
	$array_link_icon = vc_build_link( $icon_box['icon_link'] );
	if ( $array_link_icon['url'] != '' ) {
		$attr_link_icon = '';
		if ( $array_link_icon['title'] != '' ) {
			$attr_link_icon .= 'title="' . $array_link_icon['title'] . '"';
		}
		if ( $array_link_icon['target'] != '' ) {
			$attr_link_icon .= ' target="' . trim( $array_link_icon['target'] ) . '"';
		}

		$begin_tag_icon = '<a class="icon ' . $column_class . '" href="' . $array_link_icon['url'] . '" ' . $attr_link_icon . '>';
		$end_tag_icon   = '</a>';
	} else {
		$begin_tag_icon = '<div class="icon ' . $column_class . '">';
		$end_tag_icon   = '</div>';
	}

	//Title inline style
	$title_css = '';
	if ( $icon_box['title_color'] ) {
		$title_css .= 'color:' . $icon_box['title_color'] . '; ';
	}
	if ( $icon_box['title_size'] ) {
		$title_css .= 'font-size:' . $icon_box['title_size'] . 'px' . '; ';
	}
	if ( $icon_box['title_weight'] ) {
		$title_css .= 'font-weight:' . $icon_box['title_weight'] . '; ';
	}
	if ( $icon_box['title_style'] ) {
		$title_css .= 'font-style:' . $icon_box['title_style'] . '; ';
	}
	if ( $title_css ) {
		$title_css = ' style="' . $title_css . '"';
	}

	//Description inline style
	$des_css = '';
	if ( $icon_box['description_color'] ) {
		$des_css .= 'color:' . $icon_box['description_color'] . '; ';
	}
	if ( $icon_box['description_size'] ) {
		$des_css .= 'font-size:' . $icon_box['description_size'] . 'px' . '; ';
	}
	if ( $icon_box['description_weight'] ) {
		$des_css .= 'font-weight:' . $icon_box['description_weight'] . '; ';
	}
	if ( $icon_box['description_style'] ) {
		$des_css .= 'font-style:' . $icon_box['description_style'] . '; ';
	}
	if ( $des_css ) {
		$des_css = ' style="' . $des_css . '"';
	}

	// Image
	$image_size = 'thumbnail';
	if ( $icon_box['image_size'] ) {
		if ( in_array( $icon_box['image_size'], array( 'medium', 'large', 'full' ) ) ) {
			$image_size = $icon_box['image_size'];
		}

		preg_match_all( '/\d+/', $icon_box['image_size'], $size_matches );
		if ( $size_matches[0] ) {
			if ( isset ( $size_matches[0][0] ) && isset ( $size_matches[0][1] ) ) {
				$image_size = array( $size_matches[0][0], $size_matches[0][1] );
			} else {
				$image_size = array( 100, 100 );
			}
		}
	}

	$image_html = wp_get_attachment_image( $icon_box['icon_image'], $image_size );

	//Icon inline style
	$icon_css = '';
	if ( $icon_box['icon_color'] ) {
		$icon_css .= 'color:' . $icon_box['icon_color'] . '; ';
	}
	if ( $icon_box['icon_size'] ) {
		$icon_css .= 'font-size:' . $icon_box['icon_size'] . 'px; ';
	}
	if ( $icon_css ) {
		$icon_css = ' style="' . $icon_css . '"';
	}

	//Icon font type
	$icon_font = '';
	if ( $icon_box['icon_fontawesome'] ) {
		$icon_font = 'class = "' . $icon_box['icon_fontawesome'] . ' " ' . $icon_css;
	}
	if ( $icon_box['icon_openiconic'] ) {
		$icon_font = 'class = "' . $icon_box['icon_openiconic'] . ' " ' . $icon_css;
	}
	if ( $icon_box['icon_typicons'] ) {
		$icon_font = 'class = "' . $icon_box['icon_typicons'] . ' " ' . $icon_css;
	}
	if ( $icon_box['icon_entypo'] ) {
		$icon_font = 'class = "' . $icon_box['icon_entypo'] . ' " ' . $icon_css;
	}
	if ( $icon_box['icon_linecons'] ) {
		$icon_font = 'class = "' . $icon_box['icon_linecons'] . ' " ' . $icon_css;
	}
	if ( $icon_box['icon_simplelineicons'] ) {
		$icon_font = 'class = "' . $icon_box['icon_simplelineicons'] . ' " ' . $icon_css;
	}
	$icon_alignment = '';
	if ( $icon_box['alignment'] ) {
		$icon_alignment = 'style = "text-align: ' . $icon_box['alignment'] . ';"';
	}
	$icon_html =
		'<div class="vc_icon_element vc_icon_element-outer" ' . $icon_alignment . '>
			<div class="vc_icon_element-inner">
				<i ' . $icon_font . '></i>
			</div>
		</div>';

	$icon = '';
	if ( $icon_box['icon_type'] == 'image' ) {
		$icon .= $image_html;
	} else {
		$icon .= $icon_html;
	}

	//button inline style

	$but_display = '';
	if ( $icon_box['button_display'] == 'yes' ) {
		$but_display .= 'display: inline-block ;';
	} else {
		$but_display .= 'display: none;';
	}
	if ( $but_display ) {
		$but_display = ' style="' . $but_display . '"';
	}

	$link_array  = vc_build_link( $icon_box['button_link'] );
	$button_link = '';
	if ( $link_array['url'] ) {
		$button_link .= 'href="' . esc_url( $link_array['url'] ) . '"';
	}
	if ( $link_array['title'] ) {
		$button_link .= ' title="' . esc_attr( $link_array['title'] ) . '"';
	}

	$icon_box_title = '';
	if ( isset( $icon_box['title'] ) && $icon_box['title'] != '' ) {
		$icon_box_title = '<' . $icon_box['heading_tag'] . ' ' . $title_css . '>' . esc_html( $icon_box['title'] ) . '</' . $icon_box['heading_tag'] . '>';
	}

	$html = '';
	if ( $icon_box['layout'] == 'top' ) {

		$entry_css = '';
		if ( $icon_box['alignment'] ) {
			$entry_css .= 'text-align:' . $icon_box['alignment'] . '; ';
		}
		if ( $icon_box['background_color'] ) {
			$entry_css .= 'background-color:' . $icon_box['background_color'] . '; ';
		}
		if ( $entry_css ) {
			$entry_css = ' style="' . $entry_css . '"';
		}
		$html .=
			'<div class="icon-box-top ' . $css_animation . ' ' . esc_attr( $icon_box['el_class'] ) . '" ' . $entry_css . '>
				' . $begin_tag_icon . $icon . $end_tag_icon . '
				<div class="content">
					' . $icon_box_title . '
					<div class="des" ' . $des_css . '>' . $icon_box['description'] . '</div>
					<div class="gon-wrapper-button" ' . $but_display . '>
						<a ' . $button_link . ' class="wrapper-link">
							<div class="gon-button gon-button--rayen gon-button--border-thick gon-button--text-thick">
								<span class="before">' . esc_html( $icon_box['button_value'] ) . '</span>
								<span class="content">' . esc_html( $icon_box['button_value'] ) . '</span>
							</div>
						</a>
					</div>
				</div>
			</div>';
	}
	if ( $icon_box['layout'] == 'top2' ) {

		$entry_css = '';
		if ( $icon_box['alignment'] ) {
			$entry_css .= 'text-align:' . $icon_box['alignment'] . '; ';
		}
		if ( $icon_box['background_color'] ) {
			$entry_css .= 'background-color:' . $icon_box['background_color'] . '; ';
		}
		if ( $entry_css ) {
			$entry_css = ' style="' . $entry_css . '"';
		}
		$html .=
			'<div class="icon-box-top-2 ' . $css_animation . ' ' . esc_attr( $icon_box['el_class'] ) . '" ' . $entry_css . '>
				' . $begin_tag_icon . $icon . $end_tag_icon . '
				<div class="content">
					' . $icon_box_title . '
					<div class="des" ' . $des_css . '>' . $icon_box['description'] . '</div>
					<div class="gon-link-2" ' . $but_display . '><a ' . $button_link . '>' . esc_attr( $icon_box['button_value'] ) . '</a></div>
				</div>
			</div>';
	}
	if ( $icon_box['layout'] == 'left' ) {

		$content_css = '';
		if ( $icon_box['alignment'] ) {
			$content_css .= 'text-align:' . $icon_box['alignment'] . '; ';
		}
		if ( $icon_box['background_color'] ) {
			$content_css .= 'background-color:' . $icon_box['background_color'] . '; ';
		}
		if ( $content_css ) {
			$content_css = ' style="' . $content_css . '"';
		}


		$html .=
			'<div class="icon-box-left ' . $css_animation . ' ' . esc_attr( $icon_box['el_class'] ) . '" ' . $content_css . '>
				' . $begin_tag_icon . $icon . $end_tag_icon . '
				<div class="content">
					' . $icon_box_title . '
					<div class="des" ' . $des_css . '>' . esc_attr( $icon_box['description'] ) . '</div>
				</div>
				<div class="clear-fix"></div>
			</div>';
	}

	return '<div class="gon-icon-box">' . $html . '</div>';
}

add_shortcode( 'gon-icon-box', 'gon_shortcode_icon_box' );
