<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mapping shortcodes
 */
function gon_map_sc_countdown_box() {
	// Mapping shortcode Counter Box
	vc_map( array(
		'name'        => esc_html__( 'Countdown Box', 'gonthemes-helper' ),
		'base'        => 'gon-countdown-box',
		'class'       => '',
		'category'    => esc_html__( 'GonThemes Helper', 'gonthemes-helper' ),
		'description' => esc_html__( 'Display countdown box.', 'gonthemes-helper' ),
		'params'      => array(
			// Title
			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Title', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'title',
				'value'       => esc_html__( 'Product Lunch', 'gonthemes-helper' ),
			),
			// Description
			array(
				'type'        => 'textarea',
				'heading'     => esc_html__( 'Description', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'description',
				'value'       => esc_html__( 'Description', 'gonthemes-helper' ),
			),
			// Date
			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Date', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'date',
				'value'       => esc_html__( '2018/01/02', 'gonthemes-helper' ),
				"description" => esc_attr__( "Type: YYYY/MM/DD", 'gonthemes-helper' )
			),
			array(
				'type'        => 'textfield',
				'heading'     => esc_html__( 'Button', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'button',
				'value'       => esc_html__( 'Contact Now', 'gonthemes-helper' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => esc_html__( 'Button Link', 'creative-mag' ),
				'param_name' => 'link',
				'value'       => '#',
			),
			// Label
			array(
				'type'        => 'textfield',
				'group'       => esc_attr__( 'Labels', 'gonthemes-helper' ),
				'heading'     => esc_html__( 'Weeks', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'weeks',
				'value'       => esc_html__( "weeks", "gonthemes-helper" ),
				'edit_field_class' => 'vc_col-sm-4',
				"description" => esc_attr__( "Type: weeks", "gonthemes-helper" )
			),
			array(
				'type'        => 'textfield',
				'group'       => esc_attr__( 'Labels', 'gonthemes-helper' ),
				'heading'     => esc_html__( 'Days', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'days',
				'value'       => esc_html__( "days", "gonthemes-helper" ),
				'edit_field_class' => 'vc_col-sm-4',
				"description" => esc_attr__( "Type: days", "gonthemes-helper" )
			),
			
			array(
				'type'        => 'textfield',
				'group'       => esc_attr__( 'Labels', 'gonthemes-helper' ),
				'heading'     => esc_html__( 'Hours', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'hours',
				'value'       => esc_html__( "hours", "gonthemes-helper" ),
				'edit_field_class' => 'vc_col-sm-4',
				"description" => esc_attr__( "Type: hours", "gonthemes-helper" )
			),
			array(
				'type'        => 'textfield',
				'group'       => esc_attr__( 'Labels', 'gonthemes-helper' ),
				'heading'     => esc_html__( 'Minutes', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'minutes',
				'value'       => esc_html__( "minutes", "gonthemes-helper" ),
				'edit_field_class' => 'vc_col-sm-4',
				"description" => esc_attr__( "Type: minutes", "gonthemes-helper" )
			),
			array(
				'type'        => 'textfield',
				'group'       => esc_attr__( 'Labels', 'gonthemes-helper' ),
				'heading'     => esc_html__( 'Seconds', 'gonthemes-helper' ),
				'admin_label' => true,
				'param_name'  => 'seconds',
				'value'       => esc_html__( "seconds", "gonthemes-helper" ),
				'edit_field_class' => 'vc_col-sm-4',
				"description" => esc_attr__( "Type: seconds", "gonthemes-helper" )
			),
			
			// Extra class
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				'heading'     => esc_html__( 'Extra class', 'gonthemes-helper' ),
				'param_name'  => 'el_class',
				'value'       => '',
				'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'gonthemes-helper' ),
			),
		)
	) );
}
add_action( 'vc_before_init', 'gon_map_sc_countdown_box' );

/**
 * Shortcode Testimonials
 *
 * @param $atts
 *
 * @return string
 */
function gon_shortcode_countdown_box( $atts ) {

	wp_enqueue_script( 'gon-countdown-box', GON_URL . 'js/countdown-box.js', array( 'jquery' ), '', true );

	$countdown = shortcode_atts( array(
		'title'      	=> esc_html__( 'Product Lunch', 'gonthemes-helper' ),
		'description'   => esc_html__( 'Description', 'gonthemes-helper' ),
		'date'      	=> esc_html__( '2018/01/02', 'gonthemes-helper' ),
		'button'      	=> esc_html__( 'Contact Now', 'gonthemes-helper' ),
		'link'      	=> '#',
		'weeks'      	=> esc_html__( "weeks", "gonthemes-helper" ),
		'days'      	=> esc_html__( "days", "gonthemes-helper" ),
		'hours'      	=> esc_html__( "hours", "gonthemes-helper" ),
		'minutes'      	=> esc_html__( "minutes", "gonthemes-helper" ),
		'seconds'      	=> esc_html__( "seconds", "gonthemes-helper" ),
		'el_class'     => '',
	), $atts );
	$html = '';

	$html .= '<div class="countdown-box ' . esc_attr( $countdown['el_class'] ) . '">';
	$html .= '<div class="countdown-container" id="main-countdown" data-time="'.$countdown['date'].'" data-weeks="'.$countdown['weeks'].'" data-days="'.$countdown['days'].'" data-hours="'.$countdown['hours'].'" data-minutes="'.$countdown['minutes'].'" data-seconds="'.$countdown['seconds'].'"></div>';
	$html .= '<script type="text/template" id="main-countdown-template">
				<div class="time <%= label %>">
				  <span class="count curr top"><%= curr %></span>
				  <span class="count next top"><%= next %></span>
				  <span class="count next bottom"><%= next %></span>
				  <span class="count curr bottom"><%= curr %></span>
				  <span class="label"><%= label.length < 6 ? label : label.substr(0, 3)  %></span>
				</div>
				</script>';
	$html .= '<h3 class="title">'.$countdown['title'].'</h3>';
	$html .= '<p class="description">'.$countdown['description'].'</p>';
	if($countdown['button']) {
		$html .= '<a class="gon-button" href="'.$countdown['link'].'">'.$countdown['button'].'</a>';
	}
	$html .= '</div>';
	
	return $html;
}

add_shortcode( 'gon-countdown-box', 'gon_shortcode_countdown_box' );
