<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once( GON_PATH . 'shortcodes/counter-box/counter-box.php' );
require_once( GON_PATH . 'shortcodes/icon-box/icon-box.php' );
require_once( GON_PATH . 'shortcodes/google-map/google-map.php' );
require_once( GON_PATH . 'shortcodes/post-category/post-category.php' );
require_once( GON_PATH . 'shortcodes/testimonials/testimonials.php' );
require_once( GON_PATH . 'shortcodes/countdown-box/countdown-box.php' );
require_once( GON_PATH . 'shortcodes/brands/brands.php' );

if ( class_exists( 'WooCommerce' ) ) {
	require_once( GON_PATH . 'shortcodes/product-category/product-category.php' );
	require_once( GON_PATH . 'shortcodes/list-product/list-product.php' );
}