<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mapping shortcodes
 */
function gon_map_sc_list_product() {
	$order_by_values = array(
        '',
        esc_html__( 'Date', 'gonthemes-helper' ) => 'date',
        esc_html__( 'ID', 'gonthemes-helper' ) => 'ID',
        esc_html__( 'Author', 'gonthemes-helper' ) => 'author',
        esc_html__( 'Title', 'gonthemes-helper' ) => 'title',
        esc_html__( 'Modified', 'gonthemes-helper' ) => 'modified',
        esc_html__( 'Random', 'gonthemes-helper' ) => 'rand',
        esc_html__( 'Comment count', 'gonthemes-helper' ) => 'comment_count',
        esc_html__( 'Menu order', 'gonthemes-helper' ) => 'menu_order',
    );

    $order_way_values = array(
        '',
        esc_html__( 'Descending', 'gonthemes-helper' ) => 'DESC',
        esc_html__( 'Ascending', 'gonthemes-helper' ) => 'ASC',
    );
	$meta_key_values = array(
        '',
        esc_html__( 'Top rated products', 'gonthemes-helper' ) => '_wc_average_rating',
        esc_html__( 'Best Selling products', 'gonthemes-helper' ) => 'total_sales',
		esc_html__( 'Featured products', 'gonthemes-helper' ) => '_featured',
    );
	
	$args = array(
		'type' => 'post',
        'child_of' => 0,
        'parent' => '',
        'orderby' => 'id',
        'order' => 'ASC',
        'hide_empty' => false,
        'hierarchical' => 1,
        'exclude' => '',
        'include' => '',
        'number' => '',
        'taxonomy' => 'product_cat',
        'pad_counts' => false,
	);
	$product_categories_dropdown = array(esc_html__( 'All Category', 'gonthemes-helper' ) => 'all-category');
	$categories = get_categories( $args );
	if (isset($categories)) {
		foreach ($categories as $key => $cat) {
			$product_categories_dropdown[$cat->name] = $cat->slug;
			$childrens = get_term_children($cat->term_id, $cat->taxonomy);
			if ($childrens){
				foreach ($childrens as $key => $children) {
					$child = get_term_by( 'id', $children, $cat->taxonomy);
					$product_categories_dropdown[$child->name] = '--'.$child->slug;
				}
			}
		}
	}

	vc_map( 
		array(
			'name'              => esc_html__( 'List Product', 'gonthemes-helper' ),
			'base'              => 'list-product-woo',
			'category'         	=> esc_html__( 'GonThemes Helper', 'gonthemes-helper' ),
			'description'       => esc_html__( 'Display Product List.', 'gonthemes-helper' ),
			'controls'          => 'full',
			'show_settings_on_create' => true,
			'params' => array(
				array(
					'type'        => 'textfield',
					'admin_label' => true,
					'heading'     => esc_html__( 'Title', 'gonthemes-helper' ),
					'param_name'  => 'title',
					'value'       => '',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Per page', 'gonthemes-helper' ),
					'value' => 3,
					'save_always' => true,
					'param_name' => 'per_page',
					'description' => esc_html__( 'How much items per page to show', 'gonthemes-helper' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Order by', 'gonthemes-helper' ),
					'param_name' => 'orderby',
					'value' => $order_by_values,
					'save_always' => true,
					'description' => sprintf( __( 'Select how to sort retrieved products. More at %s.', 'gonthemes-helper' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Sort order', 'gonthemes-helper' ),
					'param_name' => 'order',
					'value' => $order_way_values,
					'save_always' => true,
					'description' => sprintf( esc_html__( 'Designates the ascending or descending order. More at %s.', 'gonthemes-helper' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Meta key', 'gonthemes-helper' ),
					'param_name' => 'meta_key',
					'value' => $meta_key_values,
					'save_always' => true,
					'description' => esc_html__( 'Chose type product category list', 'gonthemes-helper' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Category', 'gonthemes-helper' ),
					'value' => $product_categories_dropdown,
					'param_name' => 'category',
					'save_always' => true,
					'description' => esc_html__( 'Product category list', 'gonthemes-helper' ),
				),
				// Extra class
				array(
					'type'        => 'textfield',
					'admin_label' => true,
					'heading'     => esc_html__( 'Extra class', 'gonthemes-helper' ),
					'param_name'  => 'el_class',
					'value'       => '',
					'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'gonthemes-helper' ),
				),
			),
		) 
	);
}
add_action( 'vc_before_init', 'gon_map_sc_list_product' );

/**
 * Shortcode Product Category
 *
 * @param $atts
 *
 * @return string
 */

function gon_shortcode_list_product( $atts ) {
	$id = uniqid();
	$list_product = shortcode_atts( array(
		'title'					=> '',
		'per_page'  			=> '',
		'orderby'       		=> '',
		'order'         		=> '',
		'meta_key'      		=> '',
		'category'      		=> '',
		'el_class'           	=> '',

	), $atts );

	//button inline style
	$title 			= isset( $list_product['title'] ) ? $list_product['title'] : '';
	$per_page 		= isset( $list_product['per_page'] ) ? $list_product['per_page'] : 3;
	$orderby 		= isset( $list_product['orderby'] ) ? $list_product['orderby'] : "";
	$order 			= isset( $list_product['order'] ) ? $list_product['order'] : "";
	$meta_key 		= isset( $list_product['meta_key'] ) ? $list_product['meta_key'] : "";
	$category 		= isset( $list_product['category'] ) ? $list_product['category'] : "";
	$el_class 				= isset( $list_product['el_class'] ) ? $list_product['el_class'] : '';

	ob_start();
	$args = array(
		'posts_per_page'	=> $per_page,
		'product_cat' 		=> $category,
		'post_type'			=> 'product',
		'orderby' 			=> $orderby,
		'order'				=> $order,
	);
	if($category == "all-category") {
		$args = array(
			'posts_per_page'	=> $per_page,
			'post_type'			=> 'product',
			'orderby' 			=> $orderby,
			'order'				=> $order,
		);
	}
	if (isset($meta_key)) {
		switch ( $meta_key ) {
			case '_featured' :
				$args['meta_key'] = '_featured';
				$args['meta_value'] = 'yes';
				break;
			case 'total_sales' :
				$args['meta_key'] = 'total_sales';
				$args['orderby']  = 'meta_value_num';
				break;
			case '_wc_average_rating' :
				$args['meta_key'] = '_wc_average_rating';
				$args['orderby']  = 'meta_value_num';
				break;
		}
	}
	$query = new WP_Query( $args );
?>
<?php if($title != '') { ?>
<div class="list-product-title">
	<h3 class="heading-title"><?php echo esc_html($title); ?></h3>
</div>
<?php } ?>
<div class="list-product-content">
<?php
if ( $query->have_posts() ) : ?>
<?php while ( $query->have_posts() ) :
		$query->the_post(); global $product, $post;?>
			<div class="item-col">
				<div class="product-image">
					<a class="oneimg" href="<?php echo esc_url( get_permalink( $product->get_id() ) ); ?>" title="<?php echo esc_attr( $product->get_title() ); ?>">
						<?php 
						$image = wp_get_attachment_image_src( get_post_thumbnail_id( $product->get_id() ), 'shop_catalog' );
						$image_crop = aq_resize($image[0], 100, 100, true);
						$img = '';
						if($image_crop) {
							$img = '<img src="'.$image_crop.'" alt="'. get_the_title().'" />';
						} else {
							$img = '<img src="'.$image[0].'" alt="'.get_the_title().'" />';
						}
						echo $img;
						?>
					</a>
				</div>
				<div class="text-block">
					<h3 class="product-name">
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					</h3>
					<div class="ratings"><?php echo wc_get_rating_html( $product->get_average_rating() ); ?></div>
					<div class="price-box"><?php echo $product->get_price_html(); ?></div>
				</div>
			</div>
		<?php
	endwhile;
endif;
wp_reset_postdata();
?>
</div>
<?php
	return '<div class="list-product-woo">' . ob_get_clean() . '</div>';
}

add_shortcode( 'list-product-woo', 'gon_shortcode_list_product' );
