<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mapping shortcodes
 */
function gon_map_sc_product_carousel() {
	$order_by_values = array(
        '',
        esc_html__( 'Date', 'gonthemes-helper' ) => 'date',
        esc_html__( 'ID', 'gonthemes-helper' ) => 'ID',
        esc_html__( 'Author', 'gonthemes-helper' ) => 'author',
        esc_html__( 'Title', 'gonthemes-helper' ) => 'title',
        esc_html__( 'Modified', 'gonthemes-helper' ) => 'modified',
        esc_html__( 'Random', 'gonthemes-helper' ) => 'rand',
        esc_html__( 'Comment count', 'gonthemes-helper' ) => 'comment_count',
        esc_html__( 'Menu order', 'gonthemes-helper' ) => 'menu_order',
    );

    $order_way_values = array(
        '',
        esc_html__( 'Descending', 'gonthemes-helper' ) => 'DESC',
        esc_html__( 'Ascending', 'gonthemes-helper' ) => 'ASC',
    );
	$meta_key_values = array(
        '',
        esc_html__( 'Top rated products', 'gonthemes-helper' ) => '_wc_average_rating',
        esc_html__( 'Best Selling products', 'gonthemes-helper' ) => 'total_sales',
		esc_html__( 'Featured products', 'gonthemes-helper' ) => '_featured',
    );
	
	$args = array(
		'type' => 'post',
        'child_of' => 0,
        'parent' => '',
        'orderby' => 'id',
        'order' => 'ASC',
        'hide_empty' => false,
        'hierarchical' => 1,
        'exclude' => '',
        'include' => '',
        'number' => '',
        'taxonomy' => 'product_cat',
        'pad_counts' => false,
	);
	$product_categories_dropdown = array(esc_html__( 'All Category', 'gonthemes-helper' ) => 'all-category');
	$categories = get_categories( $args );
	if (isset($categories)) {
		foreach ($categories as $key => $cat) {
			$product_categories_dropdown[$cat->name] = $cat->slug;
			$childrens = get_term_children($cat->term_id, $cat->taxonomy);
			if ($childrens){
				foreach ($childrens as $key => $children) {
					$child = get_term_by( 'id', $children, $cat->taxonomy);
					$product_categories_dropdown[$child->name] = '--'.$child->slug;
				}
			}
		}
	}

	vc_map( 
		array(
			'name'              => esc_html__( 'Carousel Product Category', 'gonthemes-helper' ),
			'base'              => 'gon-product-category',
			'category'         	=> esc_html__( 'GonThemes Helper', 'gonthemes-helper' ),
			'description'       => esc_html__( 'Display Product Category Multi Row.', 'gonthemes-helper' ),
			'controls'          => 'full',
			'show_settings_on_create' => true,
			'params' => array(
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Style', 'gonthemes-helper' ),
					'param_name'  => 'product_style',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'Default', 'gonthemes-helper' )  => 'default',
						esc_html__( 'Product Sale', 'gonthemes-helper' ) 	=> 'sale',
					),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Per page', 'gonthemes-helper' ),
					'value' => 6,
					'save_always' => true,
					'param_name' => 'per_page',
					'description' => esc_html__( 'How much items per page to show', 'gonthemes-helper' ),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Columns', 'gonthemes-helper' ),
					'value' => 4,
					'save_always' => true,
					'param_name' => 'columns',
					'description' => esc_html__( 'How much columns grid', 'gonthemes-helper' ),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Rows', 'gonthemes-helper' ),
					'value' => 1,
					'save_always' => true,
					'param_name' => 'rows',
					'description' => esc_html__( 'How much rows grid', 'gonthemes-helper' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Order by', 'gonthemes-helper' ),
					'param_name' => 'orderby',
					'value' => $order_by_values,
					'save_always' => true,
					'description' => sprintf( __( 'Select how to sort retrieved products. More at %s.', 'gonthemes-helper' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Sort order', 'gonthemes-helper' ),
					'param_name' => 'order',
					'value' => $order_way_values,
					'save_always' => true,
					'description' => sprintf( esc_html__( 'Designates the ascending or descending order. More at %s.', 'gonthemes-helper' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Meta key', 'gonthemes-helper' ),
					'param_name' => 'meta_key',
					'value' => $meta_key_values,
					'save_always' => true,
					'description' => esc_html__( 'Chose type product category list', 'gonthemes-helper' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Category', 'gonthemes-helper' ),
					'value' => $product_categories_dropdown,
					'param_name' => 'category',
					'save_always' => true,
					'description' => esc_html__( 'Product category list', 'gonthemes-helper' ),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Desktop', 'gonthemes-helper' ),
					'value' => 4,
					'save_always' => true,
					'param_name' => 'items_desktop',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Desktop Small', 'gonthemes-helper' ),
					'value' => 3,
					'save_always' => true,
					'param_name' => 'items_desktop_small',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Tablet', 'gonthemes-helper' ),
					'value' => 3,
					'save_always' => true,
					'param_name' => 'items_tablet',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Tablet Small', 'gonthemes-helper' ),
					'value' => 2,
					'save_always' => true,
					'param_name' => 'items_tablet_small',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Mobile', 'gonthemes-helper' ),
					'value' => 1,
					'save_always' => true,
					'param_name' => 'items_mobile',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'AutoPlay', 'gonthemes-helper' ),
					'param_name'  => 'auto_play',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'False', 'gonthemes-helper' )  => 'false',
						esc_html__( 'True', 'gonthemes-helper' ) 	=> 'true',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Mouse Drag', 'gonthemes-helper' ),
					'param_name'  => 'mouse_drag',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'False', 'gonthemes-helper' )  => 'false',
						esc_html__( 'True', 'gonthemes-helper' ) 	=> 'true',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Navigation', 'gonthemes-helper' ),
					'param_name'  => 'navigation',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'True', 'gonthemes-helper' ) 	=> 'true',
						esc_html__( 'False', 'gonthemes-helper' )  => 'false',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Pagination', 'gonthemes-helper' ),
					'param_name'  => 'pagination',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'False', 'gonthemes-helper' )  => 'false',
						esc_html__( 'True', 'gonthemes-helper' ) 	=> 'true',
					),
				),
				// Extra class
				array(
					'type'        => 'textfield',
					'admin_label' => true,
					'heading'     => esc_html__( 'Extra class', 'gonthemes-helper' ),
					'param_name'  => 'el_class',
					'value'       => '',
					'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'gonthemes-helper' ),
				),
			),
		) 
	);
}
add_action( 'vc_before_init', 'gon_map_sc_product_carousel' );

/**
 * Shortcode Product Category
 *
 * @param $atts
 *
 * @return string
 */

function gon_shortcode_product_category( $atts ) {
	global $woocommerce_loop;
	$id = uniqid();
	$product_category = shortcode_atts( array(
		'product_style'			=> '',
		'per_page'  			=> '',
		'columns'      			=> '',
		'rows'      			=> '',
		'orderby'       		=> '',
		'order'         		=> '',
		'meta_key'      		=> '',
		'category'      		=> '',
		'items_desktop'      	=> '',
		'items_desktop_small'   => '',
		'items_tablet'      	=> '',
		'items_tablet_small'    => '',
		'items_mobile'      	=> '',
		'auto_play'      		=> '',
		'mouse_drag'	 		=> '',
		'navigation'			=> '',
		'pagination'      		=> '',
		'el_class'           	=> '',

	), $atts );

	//button inline style
	$product_style 	= isset( $product_category['product_style'] ) ? $product_category['product_style'] : 'default';
	$per_page 		= isset( $product_category['per_page'] ) ? $product_category['per_page'] : 6;
	$columns 		= isset( $product_category['columns'] ) ? $product_category['columns'] : 4;
	$rows 			= isset( $product_category['rows'] ) ? $product_category['rows'] : 2;
	$orderby 		= isset( $product_category['orderby'] ) ? $product_category['orderby'] : "";
	$order 			= isset( $product_category['order'] ) ? $product_category['order'] : "";
	$meta_key 		= isset( $product_category['meta_key'] ) ? $product_category['meta_key'] : "";
	$category 		= isset( $product_category['category'] ) ? $product_category['category'] : "";
	
	$items_desktop 			= isset( $product_category['items_desktop'] ) ? $product_category['items_desktop'] : 4;
	$items_desktop_small 	= isset( $product_category['items_desktop_small'] ) ? $product_category['items_desktop_small'] : 3;
	$items_tablet 			= isset( $product_category['items_tablet'] ) ? $product_category['items_tablet'] : 3;
	$items_tablet_small 	= isset( $product_category['items_tablet_small'] ) ? $product_category['items_tablet_small'] : 2;
	$items_mobile 			= isset( $product_category['items_mobile'] ) ? $product_category['items_mobile'] : 1;
	$auto_play 				= isset( $product_category['auto_play'] ) ? $product_category['auto_play'] : false;
	$mouse_drag 			= isset( $product_category['mouse_drag'] ) ? $product_category['mouse_drag'] : false;
	$navigation 			= isset( $product_category['navigation'] ) ? $product_category['navigation'] : true;
	$pagination 			= isset( $product_category['pagination'] ) ? $product_category['pagination'] : false;
	$el_class 				= isset( $product_category['el_class'] ) ? $product_category['el_class'] : '';

	ob_start();
	$woocommerce_loop['columns'] = $columns;
	$args = array(
		'posts_per_page'	=> $per_page,
		'product_cat' 		=> $category,
		'post_type'			=> 'product',
		'orderby' 			=> $orderby,
		'order'				=> $order,
	);
	if($category == "all-category") {
		$args = array(
			'posts_per_page'	=> $per_page,
			'post_type'			=> 'product',
			'orderby' 			=> $orderby,
			'order'				=> $order,
		);
	}
	if (isset($meta_key)) {
		switch ( $meta_key ) {
			case '_featured' :
				$args['meta_key'] = '_featured';
				$args['meta_value'] = 'yes';
				break;
			case 'total_sales' :
				$args['meta_key'] = 'total_sales';
				$args['orderby']  = 'meta_value_num';
				break;
			case '_wc_average_rating' :
				$args['meta_key'] = '_wc_average_rating';
				$args['orderby']  = 'meta_value_num';
				break;
		}
	}
	if($product_style == "sale") {
		$args['meta_query'] = array(
			'relation' => 'OR',
			array( // Simple products type
				'key'           => '_sale_price',
				'value'         => 0,
				'compare'       => '>',
				'type'          => 'numeric'
			),
			array( // Variable products type
				'key'           => '_min_variation_sale_price',
				'value'         => 0,
				'compare'       => '>',
				'type'          => 'numeric'
			)
		);
	}
	
	$query = new WP_Query( $args );
	$woocommerce_loop['columns'] = $columns;
	$i = 1;
	
	if ( $query->have_posts() ) :
		woocommerce_product_loop_start();
		if($rows >= 2) {
			echo '<div class="item-wrapper">';
		}
		while ( $query->have_posts() ) : $query->the_post();
			wc_get_template_part( 'content', 'product' );

			if($rows >= 2) {
				if ($i % $rows == 0 && ($query->found_posts != $i)) {
					echo '</div><div class="item-wrapper">';
				}
				$i++;
			}
		endwhile; // end of the loop.
		if($rows >= 2) {
			echo '</div>';
		}

		woocommerce_product_loop_end();
	endif;
	wp_reset_postdata();
	$themes_script = '
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		$("#carousel2-'.$id.' .shop-products").addClass("owl-carousel owl-theme");
		$("#carousel2-'.$id.' .shop-products").owlCarousel({
			items: 				'.$columns.',
			responsive : {
				0 : {
					items: 				'.$items_mobile.',
				},
				481 : {
					items: 				'.$items_tablet_small.',
				},
				767 : {
					items: 				'.$items_tablet.',
				},
				800 : {
					items: 				'.$items_tablet.',
				},
				980 : {
					items: 				'.$items_desktop_small.',
				},
				1170 : {
					items: 				'.$items_desktop.',
				},
				1200 : {
					items: 				'.$columns.',
				},
			},
			margin: 30,
			loop: true,
			autoplay: 			'.$auto_play.',			
			nav: 				'.$navigation.',
			dots: 				'.$pagination.',
			mouseDrag: 			'.$mouse_drag.',
			navText: 			["'.esc_html__("Prev", "gonthemes-helper").'", "'.esc_html__("Next", "gonthemes-helper").'"],
		});
	});
	</script>';
	return '<div id="carousel2-'.$id.'" class="carousel-product '.esc_attr($product_style).' '.esc_attr( $el_class ).'"><div class="woocommerce columns-' . $columns . '">' . ob_get_clean() . '</div></div>'.$themes_script;
}

add_shortcode( 'gon-product-category', 'gon_shortcode_product_category' );
