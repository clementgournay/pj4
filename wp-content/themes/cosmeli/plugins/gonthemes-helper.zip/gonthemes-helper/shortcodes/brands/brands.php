<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mapping shortcodes
 */
function gon_map_sc_brands() {
	// Mapping shortcode Counter Box
	vc_map( array(
		'name'        => esc_html__( 'Brand Logos', 'gonthemes-helper' ),
		'base'        => 'gon-brands',
		'class'       => '',
		'category'    => esc_html__( 'GonThemes Helper', 'gonthemes-helper' ),
		'description' => esc_html__( 'Display brands.', 'gonthemes-helper' ),
		'params'      => array(
			array(
				'type'       => 'param_group',
				'heading'    => esc_html__( 'Items', 'creative-mag' ),
				'param_name' => 'items',
				'value'      => '',
				'params'     => array(
					array(
						"type"        => "attach_image",
						"heading"     => esc_attr__( "Image", 'gonthemes-helper' ),
						"param_name"  => "brand_image",
						"admin_label" => true,
						"description" => esc_attr__( "Select an image to upload", 'gonthemes-helper' )
					),
					array(
						'type'       => 'textfield',
						'heading'    => esc_html__( 'Brand Link', 'creative-mag' ),
						'param_name' => 'brand_link',
						'value'       => '#',
					),
				)
			),
			
			// Extra class
			array(
				'type'        => 'textfield',
				'admin_label' => true,
				'heading'     => esc_html__( 'Extra class', 'gonthemes-helper' ),
				'param_name'  => 'el_class',
				'value'       => '',
				'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'gonthemes-helper' ),
			),
		)
	) );
}
add_action( 'vc_before_init', 'gon_map_sc_brands' );

/**
 * Shortcode Brand Logos
 *
 * @param $atts
 *
 * @return string
 */
function gon_shortcode_brands( $atts ) {

	wp_enqueue_script( 'gon-brands', GON_URL . 'js/brands.js', array( 'jquery' ), '', true );

	$brands = shortcode_atts( array(
		'items'      	=> '',
		'el_class'     => '',
	), $atts );
	$brands['items'] = vc_param_group_parse_atts( $brands['items'] );
	$html = '';

	$html .= '<div class="brands ' . esc_attr( $brands['el_class'] ) . '">';
	$html .= '<div class="brands-carousel owl-carousel owl-theme">';
	if ( $brands['items'] ) {
		foreach ( $brands['items'] as $key => $item ) {
			$item_img = wp_get_attachment_image_src( $item['brand_image'], 'full' );
			$img_crop = aq_resize($item_img[0], 200, 120, true);
			if($img_crop) {
				$img = '<img src="'.$img_crop.'" alt="brand">';
			} else {
				$img = '<img src="'.$item_img[0].'" alt="brand">';
			}
			$html .= '<div class="single-brands">';
				$html .= '<div class="brands-img">';
				if($item['brand_link']) {
					$html .= '<a href="'.$item['brand_link'].'">'.$img.'</a>';
				} else {
					$html .= $img;
				}
				$html .= '</div>';
			$html .= '</div>';
		}
	}
	$html .= '</div>';
	$html .= '</div>';

	return $html;
}

add_shortcode( 'gon-brands', 'gon_shortcode_brands' );
