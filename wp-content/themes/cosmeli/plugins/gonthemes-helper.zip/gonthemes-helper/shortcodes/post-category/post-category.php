<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Mapping shortcodes
 */
function gon_map_sc_post_carousel() {
	$order_by_values = array(
        '',
        esc_html__( 'Date', 'gonthemes-helper' ) => 'date',
        esc_html__( 'ID', 'gonthemes-helper' ) => 'ID',
        esc_html__( 'Author', 'gonthemes-helper' ) => 'author',
        esc_html__( 'Title', 'gonthemes-helper' ) => 'title',
        esc_html__( 'Modified', 'gonthemes-helper' ) => 'modified',
        esc_html__( 'Random', 'gonthemes-helper' ) => 'rand',
        esc_html__( 'Comment count', 'gonthemes-helper' ) => 'comment_count',
        esc_html__( 'Menu order', 'gonthemes-helper' ) => 'menu_order',
    );

    $order_way_values = array(
        '',
        esc_html__( 'Descending', 'gonthemes-helper' ) => 'DESC',
        esc_html__( 'Ascending', 'gonthemes-helper' ) => 'ASC',
    );
	
	$args2 = array(
		'type' => 'post',
        'child_of' => 0,
        'parent' => '',
        'orderby' => 'id',
        'order' => 'ASC',
	 );
	$post_category_dropdown = array();
	$post_category_dropdown['All'] = 'all';
	$categories2 = get_categories( $args2 );
	if (isset($categories2)) {
		foreach ($categories2 as $key2 => $cat2) {
			$post_category_dropdown[$cat2 -> cat_ID] = $cat2 -> cat_name;
			$childrens2 = get_term_children($cat2->term_id, $cat2->taxonomy);
			if ($childrens2){
				foreach ($childrens2 as $key2 => $children2) {
					$child2 = get_term_by( 'id', $children2, $cat2->taxonomy);
					$post_category_dropdown[$child2->term_id] = '--'.$child2->name;

				}
			}
		}
	}

	vc_map( 
		array(
			'name'              => esc_html__( 'Carousel Post Category', 'gonthemes-helper' ),
			'base'              => 'gon-post-category',
			'category'         	=> esc_html__( 'GonThemes Helper', 'gonthemes-helper' ),
			'description'       => esc_html__( 'Display Post Category.', 'gonthemes-helper' ),
			'controls'          => 'full',
			'show_settings_on_create' => true,
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Per page', 'gonthemes-helper' ),
					'value' => 6,
					'save_always' => true,
					'param_name' => 'per_page',
					'description' => esc_html__( 'How much items per page to show', 'gonthemes-helper' ),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Columns', 'gonthemes-helper' ),
					'value' => 4,
					'save_always' => true,
					'param_name' => 'columns',
					'description' => esc_html__( 'How much columns grid', 'gonthemes-helper' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Order by', 'gonthemes-helper' ),
					'param_name' => 'orderby',
					'value' => $order_by_values,
					'save_always' => true,
					'description' => sprintf( __( 'Select how to sort retrieved products. More at %s.', 'gonthemes-helper' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Sort order', 'gonthemes-helper' ),
					'param_name' => 'order',
					'value' => $order_way_values,
					'save_always' => true,
					'description' => sprintf( esc_html__( 'Designates the ascending or descending order. More at %s.', 'gonthemes-helper' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Category', 'gonthemes-helper' ),
					'value' => $post_category_dropdown,
					'param_name' => 'category',
					'save_always' => true,
					'description' => esc_html__( 'Product category list', 'gonthemes-helper' ),
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Desktop', 'gonthemes-helper' ),
					'value' => 4,
					'save_always' => true,
					'param_name' => 'items_desktop',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Desktop Small', 'gonthemes-helper' ),
					'value' => 3,
					'save_always' => true,
					'param_name' => 'items_desktop_small',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Tablet', 'gonthemes-helper' ),
					'value' => 3,
					'save_always' => true,
					'param_name' => 'items_tablet',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Tablet Small', 'gonthemes-helper' ),
					'value' => 2,
					'save_always' => true,
					'param_name' => 'items_tablet_small',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Responsive Items Mobile', 'gonthemes-helper' ),
					'value' => 1,
					'save_always' => true,
					'param_name' => 'items_mobile',
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'AutoPlay', 'gonthemes-helper' ),
					'param_name'  => 'auto_play',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'False', 'gonthemes-helper' )  => 'false',
						esc_html__( 'True', 'gonthemes-helper' ) 	=> 'true',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Mouse Drag', 'gonthemes-helper' ),
					'param_name'  => 'mouse_drag',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'False', 'gonthemes-helper' )  => 'false',
						esc_html__( 'True', 'gonthemes-helper' ) 	=> 'true',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Navigation', 'gonthemes-helper' ),
					'param_name'  => 'navigation',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'True', 'gonthemes-helper' ) 	=> 'true',
						esc_html__( 'False', 'gonthemes-helper' )  => 'false',
					),
				),
				array(
					'type'        => 'dropdown',
					'heading'     => esc_html__( 'Pagination', 'gonthemes-helper' ),
					'param_name'  => 'pagination',
					'save_always' => true,
					'value'       => array(
						esc_html__( 'False', 'gonthemes-helper' )  => 'false',
						esc_html__( 'True', 'gonthemes-helper' ) 	=> 'true',
					),
				),
				// Extra class
				array(
					'type'        => 'textfield',
					'admin_label' => true,
					'heading'     => esc_html__( 'Extra class', 'gonthemes-helper' ),
					'param_name'  => 'el_class',
					'value'       => '',
					'description' => esc_html__( 'Add extra class name that will be applied to the icon box, and you can use this class for your customizations.', 'gonthemes-helper' ),
				),
			),
		) 
	);
}
add_action( 'vc_before_init', 'gon_map_sc_post_carousel' );

/**
 * Shortcode Product Category
 *
 * @param $atts
 *
 * @return string
 */

function gon_shortcode_post_category( $atts ) {
	$id = uniqid();
	$post_category = shortcode_atts( array(
		'per_page'  			=> '',
		'columns'      			=> '',
		'orderby'       		=> '',
		'order'         		=> '',
		'category'      		=> '',
		'items_desktop'      	=> '',
		'items_desktop_small'   => '',
		'items_tablet'      	=> '',
		'items_tablet_small'    => '',
		'items_mobile'      	=> '',
		'auto_play'      		=> '',
		'mouse_drag'	 		=> '',
		'navigation'			=> '',
		'pagination'      		=> '',
		'el_class'           	=> '',

	), $atts );

	//button inline style
	$per_page 		= isset( $post_category['per_page'] ) ? $post_category['per_page'] : 12;
	$columns 		= isset( $post_category['columns'] ) ? $post_category['columns'] : 4;
	$orderby 		= isset( $post_category['orderby'] ) ? $post_category['orderby'] : "";
	$order 			= isset( $post_category['order'] ) ? $post_category['order'] : "";
	$category 		= isset( $post_category['category'] ) ? $post_category['category'] : "";
	
	$items_desktop 			= isset( $post_category['items_desktop'] ) ? $post_category['items_desktop'] : 4;
	$items_desktop_small 	= isset( $post_category['items_desktop_small'] ) ? $post_category['items_desktop_small'] : 3;
	$items_tablet 			= isset( $post_category['items_tablet'] ) ? $post_category['items_tablet'] : 3;
	$items_tablet_small 	= isset( $post_category['items_tablet_small'] ) ? $post_category['items_tablet_small'] : 2;
	$items_mobile 			= isset( $post_category['items_mobile'] ) ? $post_category['items_mobile'] : 1;
	$auto_play 				= isset( $post_category['auto_play'] ) ? $post_category['auto_play'] : false;
	$mouse_drag 			= isset( $post_category['mouse_drag'] ) ? $post_category['mouse_drag'] : false;
	$navigation 			= isset( $post_category['navigation'] ) ? $post_category['navigation'] : true;
	$pagination 			= isset( $post_category['pagination'] ) ? $post_category['pagination'] : false;
	$el_class 				= isset( $post_category['el_class'] ) ? $post_category['el_class'] : '';
	
	ob_start();
	$args = array(
		'posts_per_page'	=> $per_page,
		'cat' 				=> $category,
		'post_type'			=> 'post',
		'orderby' 			=> $orderby,
		'order'				=> $order,
	);
	if($category == "all") {
		$args = array(
			'posts_per_page'	=> $per_page,
			'post_type'			=> 'post',
			'orderby' 			=> $orderby,
			'order'				=> $order,
		);
	}
	$query = new WP_Query( $args );
	

	if ( $query->have_posts() ) :
		while ( $query->have_posts() ) : $query->the_post();
			echo '<div class="post-item">';
			get_template_part('content', 'carousel');
			echo '</div>';
		endwhile; // end of the loop.
	endif;
	wp_reset_postdata();
	$gon_script = '
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		$("#carousel-post-'.$id.'").addClass("owl-carousel owl-theme");
		$("#carousel-post-'.$id.'").owlCarousel({
			items: 				'.$columns.',
			responsive : {
				0 : {
					items: 				'.$items_mobile.',
				},
				450 : {
					items: 				'.$items_tablet_small.',
				},
				650 : {
					items: 				'.$items_tablet.',
				},
				800 : {
					items: 				'.$items_tablet.',
				},
				980 : {
					items: 				'.$items_desktop_small.',
				},
				1170 : {
					items: 				'.$items_desktop.',
				},
				1200 : {
					items: 				'.$columns.',
				},
			},			
			margin: 30,
			loop: true,
			autoplay: 			'.$auto_play.',			
			nav: 				'.$navigation.',
			dots: 				'.$pagination.',
			mouseDrag: 			'.$mouse_drag.',
			navText: 			["'.esc_html__("Prev", "gonthemes-helper").'", "'.esc_html__("Next", "gonthemes-helper").'"],
		});
	});
	</script>';
	return '<div id="carousel-post-'.$id.'" class="carousel-post '.esc_attr( $el_class ).'">' . ob_get_clean() . '</div>'.$gon_script;
}

add_shortcode( 'gon-post-category', 'gon_shortcode_post_category' );
